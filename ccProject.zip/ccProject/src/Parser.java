import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;
import java.util.Stack;
import java.util.StringTokenizer;

public class Parser {

    static String Input;
    static int no_of_Tokens = 0;
    static String[][] pTable = {
            { "s5", "","", "s4","", "","1", "2","3"},
            { "", "s6","", "", "", "acc","", "",""},
            { "", "r2","s7", "","r2", "r2","", "",""},
            { "", "r4","r4", "","r4", "r4","", "",""},
            { "s5", "","", "s4","", "","8", "2","3"},
            { "", "r6","r6", "","r6", "r6","", "",""},
            { "s5", "","", "s4","", "","", "9","3"},
            { "s5", "","", "s4","", "","", "","10"},
            { "", "s6","", "","s11", "","", "",""},
            { "", "r1","s7", "","r1", "r1","", "",""},
            { "", "r3","r3", "","r3", "r3","", "",""},
            { "", "r5","r5", "","r5", "r5","", "",""},
    };



    public static String Input_to_String(String Input) {
        String inputString = "";
        while (Input.charAt(0) != '$') {
            if((Input.charAt(0)=='i'))
            {
                Input = Input.substring(2);
                inputString = inputString.concat("id ");

            }

            else if((Input.charAt(0)=='+'))
            {
                Input = Input.substring(1);
                inputString = inputString.concat("+ ");

            }

            else if((Input.charAt(0)=='*'))
            {
                Input = Input.substring(1);
                inputString = inputString.concat("* ");

            }

            else if((Input.charAt(0)=='E'))
            {
                Input = Input.substring(1);
                inputString = inputString.concat("E ");

            }

            else if((Input.charAt(0)=='T'))
            {
                Input = Input.substring(1);
                inputString = inputString.concat("T ");

            }

            else if((Input.charAt(0)=='F'))
            {
                Input = Input.substring(1);
                inputString = inputString.concat("F ");

            }

            else{
                error();
            }

        }
        inputString = inputString.concat("$");
        return inputString;
    }

    public static String rules(String ac) {
        String r = "";
        if("r1".equals(ac))
        {
            r = "E → E+T";
            return r;
        }
        if("r2".equals(ac))
        {
            r = "E → T";
            return r;
        }
        if("r3".equals(ac))
        {
            r = "T → T*F";
            return r;
        }
        if("r4".equals(ac))
        {
            r = "T → F";
            return r;
        }
        if("r5".equals(ac))
        {
            r = "F → (E)";
            return r;
        }
        if("r6".equals(ac))
        {
            r = "F → id";
            return r;
        }
        return r;
    }
    public static void error() {
        System.out.println("Syntax Error");
        System.exit(0);
    }

    public static int Index(String tk)  {
        int i = -1;
        if("id".equals(tk))
        {
            i = 0;
            return i;
        }
        if("+".equals(tk))
        {
            i = 1;
            return i;
        }
        if("*".equals(tk))
        {
            i = 2;
            return i;
        }
        if("(".equals(tk))
        {
            i = 3;
            return i;
        }
        if(")".equals(tk))
        {
            i = 4;
            return i;
        }
        if("$".equals(tk))
        {
            i = 5;
            return i;
        }
        if("E".equals(tk))
        {
            i = 6;
            return i;
        }
        if("T".equals(tk))
        {
            i = 7;
            return i;
        }
        if("F".equals(tk))
        {
            i = 8;
            return i;
        }
        else
        {
            error();
        }
        return i;
    }

    public static String remainInput(String inputString, int number_Of_Tokens, int tokenCount) {
        StringTokenizer st = new StringTokenizer(inputString);
        String remaining = "";

        for (int j = 0; j < number_Of_Tokens; j++) {
            st.nextToken();
        }

        for (int j = number_Of_Tokens; j < tokenCount; j++) {
            remaining = remaining.concat(st.nextToken());
        }

        return remaining;
    }

    public static void p() throws IOException {
        File f = new File("Pinput.txt");
        int o=1;
        Scanner input = new Scanner(f);
        while (input.hasNext()) {
            //System.out.println("take input");
            Input = input.next();
        }

        String inputString = Input_to_String(Input);
        StringTokenizer st = new StringTokenizer(inputString);
        System.out.println("Input : " + Input);
        System.out.println("Input\t\t\tAction");
        Stack s = new Stack();
        s.push("0");
        int tokenCount = st.countTokens();
        String str = st.nextToken();
        do {
            int index = Index(str);
            String ac = pTable[Integer.parseInt((String) s.peek())][index];
            switch (ac.charAt(0)) {
                case 's':
                    String number = pTable[Integer.parseInt((String) s.peek())][index].substring(1);
                    String ri = remainInput(inputString, no_of_Tokens, tokenCount);
                    no_of_Tokens++;
                    if(o<7){
                        System.out.println(  ri+ "\t\tShift by  "+ ac);
                    }
                    else{
                        System.out.println(  ri+ "\t\t\tShift by  "+ ac);
                    }
                    o++;
                    s.push(str);
                    s.push(number);
                    str = st.nextToken();
                    break;
                case 'r':
                    number = pTable[Integer.parseInt((String) s.peek())][index].substring(1);
                    String rule = rules(ac);
                    String rin = remainInput(inputString, no_of_Tokens, tokenCount);
                    if(o<7){
                        System.out.println(  rin+ "\t\tReduce by  "+ rule+ "("+ ac+ ")");
                    }
                    else{
                        System.out.println(  rin+ "\t\t\tReduce by  "+ rule+ "("+ ac+ ")");
                    }
                    o++;
                    int popTimes = 6;
                    if (Integer.parseInt(number) % 2 == 0) {
                        popTimes = 2;
                    }
                    for (int i = 0; i < popTimes; i++) {
                        s.pop();
                    }

                    String left_side = "";
                    if(Integer.parseInt(number)==1)
                    {
                        left_side = "E";
                    }
                    else if(Integer.parseInt(number)==2)
                    {
                        left_side = "E";

                    }
                    else if(Integer.parseInt(number)==3)
                    {
                        left_side = "T";

                    }
                    else if(Integer.parseInt(number)==4)
                    {
                        left_side = "T";

                    }
                    else if(Integer.parseInt(number)==5)
                    {
                        left_side = "F";

                    }
                    else if(Integer.parseInt(number)==6)
                    {
                        left_side = "F";

                    }

                    int i = -1;
                    switch (left_side.charAt(0)) {
                        case 'E':
                            i = 6;
                            break;
                        case 'T':
                            i = 7;
                            break;
                        case 'F':
                            i = 8;
                            break;
                    }
                    int num = Integer.parseInt(pTable[Integer.parseInt((String) s.peek())][i]);
                    s.push(left_side + "");
                    s.push(num + "");

                    break;
                case 'a':
                    System.out.println( s.toString()+ "\t\t$ Accept");
                    return;
            }
        } while (true);
    }
}


