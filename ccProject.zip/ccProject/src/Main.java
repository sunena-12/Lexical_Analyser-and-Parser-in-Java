import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) throws IOException {

        File file = null;
        Scanner sc = new Scanner(System.in);
        boolean check =true;
        while(check) {
            System.out.println("1. LEXICAL ANALYSIS\n2.PARSING\n3. EXIT\n\nEnter Your Choice: ");
            int choice = sc.nextInt();

            switch (choice) {

                case 1:

                    try {

                        file = new File("Removing.txt");
                        String filename = "FileInput.txt";

                        Lexical lexicalAnalyzer_obj = new Lexical(file);

                        if (lexicalAnalyzer_obj.removeCommentsFromSourceCode(lexicalAnalyzer_obj.getFileData(filename), filename, "Removing.txt")) {

                            List<Token> tokenList = lexicalAnalyzer_obj.makeTokens(file, "Removing.txt");
                            Token tempToken = null;

                            System.out.println("\n\n-----------------------LEXICAL ANALYSIS-----------------------\n\n");

                            System.out.println("LEXEMES\t\t\tTOKENS\t\t\tLINE NO\t\tATTRIBUTE VALUE");
                            for (int l = 0; l < tokenList.size(); l++) {
                                tempToken = tokenList.get(l);
                                if (tokenList.get(l).token.toLowerCase().equals("Error") || tokenList.get(l).token.toLowerCase().equals("Not Declared"))
                                    System.out.println(tempToken.printError(tempToken.lineNo, "Lexical Error".toUpperCase(), tempToken.lexeme, "Unrecognized Token "));
                                else
                                    System.out.println(tokenList.get(l).toString());

                            }

                            lexicalAnalyzer_obj.bufferedReader.close();

                        } else {
                            System.out.println("");
                        }

                    } catch (Exception e) {
                        e.printStackTrace();
                        System.out.println(e);
                    }

                    break;

                case 2:
                    Parser.p();

                case 3:
                    check = false;
                    System.exit(0);
                    System.out.println("THANKYOU");
                    break;
                default:
                    System.out.println("Wrong Input!\nTry Again");
                    break;

            }
        }


    }

}
