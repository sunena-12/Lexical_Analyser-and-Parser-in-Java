public class Token {

    public String token;
    public String lexeme;
    public int lineNo;
    public String attributeValue;
    public String errorMessage;

    public Token(String token, String lexeme, int lineNo, String attributeValue) {

        this.token = token;
        this.lexeme = lexeme;
        this.lineNo = lineNo;
        this.attributeValue = attributeValue;

    }


    public Token(int lineNo, String token, String lexeme, String errorMessage){
        this.token = token;
        this.lineNo = lineNo;
        this.lexeme = lexeme;
        this.errorMessage = errorMessage;
    }

    public String toString() {
        return formatOutPut(lexeme,token,lineNo,attributeValue);
    }

    public String printError(int lineNo, String errorName, String lexeme, String errorMessage){
        return "Error at line [ "+lineNo+" ]  "+errorName.toUpperCase()+" Lexeme [ "+lexeme+" ]  "+errorMessage+"\n";
    }


    private String formatOutPut(String lexeme,String token,int lineNo, String attributeValue){
        return lexeme +"\t\t\t"+ token +"\t\t\t"+ lineNo +"\t\t\t"+attributeValue+"\n";
    }


}

