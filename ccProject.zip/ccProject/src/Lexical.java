import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

interface Lexicall{

    boolean isCharacter(char currentChar); // to check that given character is a character or not
    boolean isNumber(char currentChar); // to check that given character is a number or not
    char nextCharacter(); // to read the next character from text file
    Token nextToken(); // to read the next token
    String getFileData(String filename); // get the source code from given filename
    boolean overWriteFileData(String filteredCode, String filename); // overwrite the filtered code to a new text file
    boolean removeCommentsFromSourceCode(String sourceCode, String filename, String filename2); // remove comments from the source code
    List<Token> makeTokens(File file, String filename); // this will do our token recognition part

}

public class Lexical implements Lexicall{

    public BufferedReader bufferedReader; // buffered reader to read the file
    public char currentCharacter; // to save the  current character
    public List<Token> tokenList = new ArrayList<>(); // array list of tokens
    public int line_no = 1; // line number
    public ArrayList<Token> errorList = new ArrayList<Token>();
    private int state;
    public static final String[] reservedKeywords = new String[]{ "import", "class", "while", "if", "else", "public", "private", "protected", "switch", "case", "super", "static", "implements", "interface", "package", "new", "continue", "try", "this", "final", "byte", "int", "char", "String", "float", "double", "boolean", "return"}; // reserved keywords of java

    public Lexical(File file) {

        try {
            bufferedReader = new BufferedReader(new FileReader(file));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        currentCharacter = nextCharacter();

    }


    public String getFileData(String filename){

        String data="";

        try {

            data = new String(Files.readAllBytes(Paths.get(filename)));
        }
        catch (Exception exception){
            exception.printStackTrace();
        }

        return data;

    }


    public boolean overWriteFileData(String filteredCode, String filename){

        boolean overWrite = false;

        try {

            FileWriter fileWriter = new FileWriter(filename);
            String code = filteredCode;
            fileWriter.write(code);
            fileWriter.close();
            overWrite = true;

        }

        catch (Exception exception){

            exception.printStackTrace();

        }

        return overWrite;

    }



    public boolean removeCommentsFromSourceCode(String sourceCode, String filename, String filename1){

        boolean commentsRemoved = false;

        sourceCode = getFileData(filename);

        String remove = sourceCode.replaceAll("(/\\*([^*]|[\\r\\n]|(\\*+([^*/]|[\\r\\n])))*\\*+/)|(//.*)","");
        remove = remove.replaceAll("\t","");

        if (overWriteFileData(remove, filename1) ) {

            commentsRemoved = true;

        }

        return commentsRemoved;

    }



    public List<Token> makeTokens(File file, String filename) {

        Token token = nextToken();

        while (token != null) {

            tokenList.add(token);
            token = nextToken();

        }

        return tokenList;

    }

    public Token nextToken() {

        state = 1;

        while (true) {

            if (currentCharacter == (char) (-1)) {

                try {

                    bufferedReader.close();

                } catch (IOException e) {

                    e.printStackTrace();
                    System.out.println(e);

                }
                return null;

            }

            switch (state) {

                case 1: {

                    if (currentCharacter == ' ' || currentCharacter == '\n' || currentCharacter == '\t' || currentCharacter == '\f' || currentCharacter == '\b' || currentCharacter == '\r') {
                        currentCharacter = nextCharacter();
                        if (currentCharacter == '\n'){
                            line_no++;
                        }
                        continue;
                    }
                    else if (currentCharacter == ';') {
                        currentCharacter = nextCharacter();
                        return new Token("terminator(oo)", ";",line_no,"tr");
                    }

                    else if (currentCharacter == '-') {
                        currentCharacter = nextCharacter();
                        return new Token("Minus(ao)", "-", line_no, "sb");
                    }
                    else if (currentCharacter == '+') {
                        currentCharacter = nextCharacter();
                        return new Token("Plus(ao)", "+",line_no,"ad");
                    }
                    else if (currentCharacter == '/') {
                        currentCharacter = nextCharacter();
                        return new Token("Division(ao)", "/", line_no, "dv");
                    }
                    else if (currentCharacter == '*') {
                        currentCharacter = nextCharacter();
                        return new Token("Multiplication(ao)", "*",line_no, "ml");
                    }

                    else if (currentCharacter == '{') {
                        currentCharacter = nextCharacter();
                        return new Token("Left braces(oo)", "{",line_no, "ob");
                    }
                    else if (currentCharacter == '}') {
                        currentCharacter = nextCharacter();
                        return new Token("Right braces(oo)", "}", line_no, "cb");
                    }
                    else if (currentCharacter == '(') {
                        currentCharacter = nextCharacter();
                        return new Token("Left Parentheses(oo)", "(" ,line_no, "op");
                    }
                    else if (currentCharacter == ')') {
                        currentCharacter = nextCharacter();
                        return new Token("Right Parentheses(oo)", ")", line_no,"cp");
                    }
                    else if (currentCharacter == '%') {
                        currentCharacter = nextCharacter();
                        return new Token("Remainder(oo)", "%", line_no, "rm");
                    }
                    else if (currentCharacter == ',') {
                        currentCharacter = nextCharacter();
                        return new Token("Comma(oo)", ",",line_no,"cm");
                    }
                    else if (currentCharacter == '=') {
                        currentCharacter = nextCharacter();
                        if (currentCharacter == '=') {
                            currentCharacter = nextCharacter();
                            return new Token("Equal Operator(ro)", "==",line_no,"eq");
                        }
                        else {
                            return new Token("Assign Operator(oo)", "=",line_no,"as");
                        }
                    }
                    else if (currentCharacter == '!') {
                        currentCharacter = nextCharacter();
                        if (currentCharacter == '=') {
                            currentCharacter = nextCharacter();
                            return new Token("Not Equal Operator (lo)", "!=",line_no,"ne");
                        }
                        else {
                            errorList.add(new Token("Not Defined", "!",line_no,"Error"));
                            return new Token("Not Defined", "!",line_no,"Error");
                        }
                    }
                    else if(currentCharacter == '&'){
                        currentCharacter = nextCharacter();
                        if(currentCharacter == '&'){
                            currentCharacter = nextCharacter();
                            return new Token("Conditional And (lo)","&&",line_no, "ca");
                        }
                        else{
                            errorList.add(new Token("Not Defined","&", line_no,"Error"));
                            return new Token("Not Defined","&", line_no,"Error");
                        }
                    }
                    else if(currentCharacter == '|') {
                        currentCharacter = nextCharacter();
                        if (currentCharacter == '|') {
                            currentCharacter = nextCharacter();
                            return new Token("Conditional Or (lo)", "||",line_no,"co");
                        }
                        else {
                            errorList.add(new Token("Not Defined", "|", line_no,"Error"));
                            return new Token("Not Defined", "|", line_no,"Error");
                        }
                    }
                    else {
                        state = 2;
                        continue;
                    }

                }
                case 2: {

                    if (isNumber(currentCharacter)) {
                        String num = String.valueOf(currentCharacter);

                        for (; ; ) {
                            currentCharacter = nextCharacter();
                            if (isNumber(currentCharacter) || currentCharacter == '.') {
                                num += String.valueOf(currentCharacter);
                            } else {
                                if (num.contains("."))
                                    return new Token("Decimal", num, line_no, num);
                                else {
                                    return new Token("in", num, line_no, num);
                                }
                            }
                        }
                    } else state = 3;
                }
                case 3: {
                    if (isCharacter(currentCharacter) || currentCharacter == '_') {
                        String word = String.valueOf(currentCharacter);
                        for (; ; ) {
                            currentCharacter = nextCharacter();
                            if (isCharacter(currentCharacter) || currentCharacter == '_' || isNumber(currentCharacter)) {
                                word += String.valueOf(currentCharacter);
                            } else {
                                List keywordsList = Arrays.asList(reservedKeywords);

                                if (keywordsList.contains(word))
                                    return new Token("Keyword", word,line_no,"rk");
                                else return new Token("id", word,line_no,word);
                            }
                        }
                    } else {
                        currentCharacter = nextCharacter();
                        errorList.add(new Token("Error",""+currentCharacter,line_no,"Error" ));
                        return new Token("Error",""+currentCharacter,line_no,"Error" );
                    }
                }
            }
        }


    }

    public char nextCharacter() {

        try {
            return (char) bufferedReader.read();

        } catch (IOException e) {

            e.printStackTrace();
            System.out.println(e);

        }

        return (char) (-1);

    }

    public boolean isNumber(char currentCharacter) {

        if (currentCharacter >= '0' && currentCharacter <= '9')
            return true;

        return false;
    }


    public boolean isCharacter(char currentCharacter) {

        if (currentCharacter >= 'a' && currentCharacter <= 'z')
            return true;

        if (currentCharacter >= 'A' && currentCharacter <= 'Z')
            return true;

        return false;

    }

}

